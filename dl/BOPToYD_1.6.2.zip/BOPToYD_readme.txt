WARNING! This game contains rapidly flashing, multicolored lights! If you have epilepsy, please avoid playing this game!

This is not a standard adventure game where you travel by typing north, east, south, and west!
To go to a location or thing, simply type that location or thing in the "Where will you go? Prompt."

With that out of the way, welcome, human!
Thank you for downloading BECOME OP 1.6: Tale of (Your) Despair.
This game's development has kind of a wierd history, and almost didn't get released in the state in which you'll see it now.
The original BECOME OP was the first game I ever released publically, despite making many prior. Development began in 2018, but I was still quite inexperienced.
I then attempted to create BECOME OP 1.5, a Japan exclusive expainsion for the game that was to add extra content to try and draw in a new audience to the series.
You could call this the third game of the BECOME OP franchise, but really, I'd like it to be thought of as the first, and the original two to be seen as an alpha and a beta.
This game contains no music. The intention is for the player to listen to whatever music they'd like during gameplay, as to make the experience more personalized.

See BOPToYD_cheatsheet.txt for a list of in-game locations, every attack and what they do, and actual cheat codes!
If you struggle with the game, you may need them.
An in-depth walkthrough will also be available on invinciblespeed.github.io a few days after release.

And that's the introduction.
Thanks to current you for reading this readme, and thanks to future you for playing the game.