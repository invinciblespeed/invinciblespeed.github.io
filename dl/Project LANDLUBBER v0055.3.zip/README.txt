WARNING! This game contains rapidly flashing, multicolored lights! If you have epilepsy, please avoid playing this game!

This is not a standard adventure game where you travel by typing north, east, south, and west!
To go to a location or thing, simply type that location or thing in the "Where will you go?" prompt.
If you would like to go to what is considered the previous location, type "BACK" in the prompt.
If music continues to play after you close the game out, run "stopsound.bat" to shut it off.

Project LANDLUBBER is the demo codename for the next major text adventure game I plan on creating.
This demo should only take ~20 minutes to complete for your first time through, but plenty of fun will be had!

Like the demo? Find more like it at invinciblespeed.github.io!

Thank you for playing.